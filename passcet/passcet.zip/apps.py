from django.apps import AppConfig


class PasscetConfig(AppConfig):
    name = 'passcet'
